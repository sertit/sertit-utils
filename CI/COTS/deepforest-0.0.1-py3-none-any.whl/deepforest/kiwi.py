import os
import logging

from deepforest.utils.system_tools import setup_environ

if os.path.exists('logging_config.ini'):
    print("Reading logging config file")
    logging.config.fileConfig('logging_config.ini')
# else:
#     logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('deepforest')
logger.debug('Logger was set up')

setup_environ()

import numpy as np
from tqdm import tqdm
import json

from deepforest.utils import io_tools, rasterio_tools, Indices


def add_kiwi_keys(kiwi_parser, kiwi_corresponding_keys):
    """
    Add kiwi specific keys to the parser and to the correspondence dictionary.
    :param kiwi_parser: Kiwi parser
    :param kiwi_corresponding_keys: Correspondence dictionary
    :return: Kiwi parser and correspondence dictionary
    """
    # Bands folder
    kiwi_parser.add_argument("-f", "--bands_folder", help='Bands Folder (relative or absolute path)')
    kiwi_corresponding_keys["KIWI/Bands Folder"] = "bands_folder"

    # AOI
    kiwi_parser.add_argument("-a", "--aoi", help='AOI shapefile (relative or absolute path)')
    kiwi_corresponding_keys["KIWI/AOI"] = "aoi"

    # AOI name
    kiwi_parser.add_argument("-an", "--aoi_name", help='AOI name, i.e. training_aoi')
    kiwi_corresponding_keys["KIWI/AOI Name"] = "aoi_name"

    # Product level
    kiwi_parser.add_argument("-p", "--product_level", help='Product Level, L1C or L2A')
    kiwi_corresponding_keys["KIWI/Product Level"] = "product_level"

    # Stack File
    kiwi_parser.add_argument("-s", "--stack", help='Stack filename, i.e. BIG_STACK.tif')
    kiwi_corresponding_keys["KIWI/Stack File Name"] = "stack"

    # Indices
    kiwi_parser.add_argument("-i", "--indices", help='List of indices, i.e. NDVI NDWI', nargs='*', default=None)
    kiwi_corresponding_keys["KIWI/Indices"] = "indices"

    # Indices
    kiwi_parser.add_argument("-b", "--bands", help='List of bands, i.e. 02 03 04', nargs='*', default=None)
    kiwi_corresponding_keys["KIWI/Bands"] = "bands"

    # Stack File
    kiwi_parser.add_argument("-r", "--resolution", help='Resolution in m')
    kiwi_corresponding_keys["KIWI/Resolution"] = "resolution"

    return kiwi_parser, kiwi_corresponding_keys


def manage_kiwi_data(kiwi_data_dict):
    """
    - Manage mandatory arguments
    - Check existence and save absolute path in kiwi data dictionary
    :param kiwi_data_dict: kiwi data dictionary
    """
    # -- Manage mandatory arguments
    mandatory_args = ['Bands Folder', 'Product Level', 'Stack File Name', 'Indices', 'Bands']
    if not all(mandatory_key in kiwi_data_dict for mandatory_key in mandatory_args):
        raise Exception('Missing mandatory argument in {}'.format(mandatory_args))

    # -- Manage paths
    # Bands
    bands_folder = os.path.abspath(kiwi_data_dict["Bands Folder"])
    if not os.path.exists(bands_folder):
        raise Exception("Non existing Bands Folder: {}".format(bands_folder))
    kiwi_data_dict["Bands Folder"] = bands_folder

    # AOI
    if 'AOI' in kiwi_data_dict:
        aoi_shp = os.path.abspath(kiwi_data_dict["AOI"])
        if not os.path.exists(aoi_shp):
            raise Exception("Non existing AOI shapefile: {}".format(aoi_shp))
        if not aoi_shp.endswith('.shp'):
            raise Exception("AOI should be a shapefile: {}".format(aoi_shp))
        kiwi_data_dict["AOI"] = aoi_shp

    # -- Check validity of inputs
    # Product level
    product_levels = ["L1C", "L2A"]
    if kiwi_data_dict["Product Level"] not in product_levels:
        raise Exception("Unknown given product level: {}. "
                        "Should be on of the following: {}".format(kiwi_data_dict["Product Level"], product_levels))

    # Data integrity
    if len(kiwi_data_dict["Indices"]) < 1 and len(kiwi_data_dict["Bands"]) < 1:
        raise Exception("At least one band or indice should be specified.")

    # Stack File
    stack_file = os.path.basename(kiwi_data_dict["Stack File Name"])
    if len(os.path.splitext(stack_file)) < 2:
        stack_file = stack_file + '.tif'
    kiwi_data_dict["Stack File Name"] = stack_file

    # Resolution
    kiwi_data_dict["Resolution"] = float(kiwi_data_dict.get("Resolution", 10.))


def launch_kiwi(working_directory, kiwi_data):
    setup_environ()

    # Just in case
    os.makedirs(working_directory, exist_ok=True)

    # Get kiwi specific data
    dir_bands = kiwi_data['Bands Folder']
    PL = kiwi_data['Product Level']
    idx_list = kiwi_data['Indices']
    bbands = kiwi_data['Bands']
    res = kiwi_data['Resolution']

    bands_to_be_loaded = bbands.copy()
    for idx in idx_list:
        bands_to_be_loaded += Indices.INDICE_TO_BAND[idx]
    bands_to_be_loaded = ['B' + band_num for band_num in set(bands_to_be_loaded)]

    aoi_shapefile_fp = None
    if "AOI" in kiwi_data:
        aoi_shapefile_fp = kiwi_data['AOI']

    if 'AOI Name' not in kiwi_data or not kiwi_data['AOI Name']:
        current_aoi_name = 'aoi'
    else:
        current_aoi_name = kiwi_data['AOI Name']

    # Output folder
    Output = os.path.join(working_directory, kiwi_data['Stack File Name'])
    os.makedirs(os.path.dirname(Output), exist_ok=True)

    # -- Load bands
    logger.info('Loading bands')
    b = {}
    crs = None
    transform = None

    # L1C bands
    if PL == 'L1C':
        for band in tqdm(os.listdir(dir_bands), desc='Loading bands'):
            for band_name in bands_to_be_loaded:
                num = band_name[1:]
                if band.endswith('.jp2') and band.upper().find(band_name.upper()) is not -1:
                    loaded_band, crs, transform = rasterio_tools.loadband(os.path.join(dir_bands, band), res,
                                                                          aoi_shapefile_fp, current_aoi_name)
                    b[num] = loaded_band

    # L2A bands
    elif PL == 'L2A':
        band_list_10 = list({'B02', 'B03', 'B04', 'B08'} & set(bands_to_be_loaded))
        band_list_20 = list({'B05', 'B06', 'B07', 'B11', 'B12'} & set(bands_to_be_loaded))
        band_list_60 = list({'B01', 'B09'} & set(bands_to_be_loaded))
        for band_name in tqdm(band_list_10, desc='Loading 10m bands'):
            for band in os.listdir(os.path.join(dir_bands, 'R10m')):
                num = band_name[1:]
                if band.endswith('.jp2') and band.upper().find(band_name.upper()) is not -1:
                    loaded_band, crs, transform = rasterio_tools.loadband(os.path.join(dir_bands, 'R10m', band), res,
                                                                          aoi_shapefile_fp, current_aoi_name)
                    b[num] = loaded_band
        for band_name in tqdm(band_list_20, desc='Loading 20m bands'):
            for band in os.listdir(os.path.join(dir_bands, 'R20m')):
                num = band_name[1:]
                if band.endswith('.jp2') and band.upper().find(band_name.upper()) is not -1:
                    loaded_band, crs, transform = rasterio_tools.loadband(os.path.join(dir_bands, 'R20m', band), res,
                                                                          aoi_shapefile_fp, current_aoi_name)
                    b[num] = loaded_band
        for band_name in tqdm(band_list_60, desc='Loading 60m bands'):
            for band in os.listdir(os.path.join(dir_bands, 'R60m')):
                num = band_name[1:]
                if band.endswith('.jp2') and band.upper().find(band_name.upper()) is not -1:
                    loaded_band, crs, transform = rasterio_tools.loadband(os.path.join(dir_bands, 'R60m', band), res,
                                                                          aoi_shapefile_fp, current_aoi_name)
                    b[num] = loaded_band

    Base_bands = []

    # Append all bands to Base_bands
    for bn in bbands:
        Base_bands.append(np.nan_to_num(b[bn]))

    # Append indices
    for i in idx_list:
        func = getattr(Indices, i)
        Base_bands.append(np.nan_to_num(func(b)))
        logger.debug('Done for %s' % i)

    # If needed, preprocess some indices
    if 'pre' in kiwi_data:
        pre_bands_fold = kiwi_data['pre']
        b_pre = {}
        pre_band_list = ['B12', 'B08', 'B04']
        for band in tqdm(os.listdir(pre_bands_fold), desc='Loading bands'):
            for band_name in pre_band_list:
                num = band_name[1:]
                if band.endswith('.jp2') and band.upper().find(band_name.upper()) is not -1:
                    loaded_band, crs, transform = rasterio_tools.loadband(os.path.join(pre_bands_fold, band), res,
                                                                          aoi_shapefile_fp, current_aoi_name)
                    b_pre[num] = loaded_band
        func = getattr(Indices, 'NDVI')
        func2 = getattr(Indices, 'BAI')
        func3 = getattr(Indices, 'NBR')
        post_ndvi = Base_bands[idx_list.index("NDVI") + len(bbands)]
        post_nbr = Base_bands[idx_list.index("NBR") + len(bbands)]
        post_bai = Base_bands[idx_list.index("BAI") + len(bbands)]
        Base_bands.append(np.nan_to_num(np.subtract(func(b_pre), post_ndvi)))
        Base_bands.append(np.nan_to_num(np.subtract(func3(b_pre), post_nbr)))
        Base_bands.append(np.nan_to_num(np.subtract(func2(b_pre), post_bai)))

    if not crs:
        raise Exception('Empty CRS')

    # Get stack and convert NaN to zeros
    logger.info('Creating stack')
    stack = np.dstack(Base_bands)
    logger.debug("Stack's shape: {}".format(stack.shape))

    logger.debug("Output %s" % Output)
    rasterio_tools.array2rasterX(Output, stack, crs, transform)

    logger.info('Kiwi is done, find your output here %s' % Output)


if __name__ == "__main__":
    try:
        # Get default parser and default corresponding keys
        parser, corresponding_keys = io_tools.create_io_overriding_argparser()

        # Add kiwi specific keys
        parser, corresponding_keys = add_kiwi_keys(parser, corresponding_keys)

        # Parse command line
        args = parser.parse_args()

        # Manage configuration
        all_data = io_tools.parse_and_override_config_file(args, corresponding_keys)

        # Initialize I/O
        working_directory = io_tools.init_io(all_data, module_name='KIWI')
        logger.debug('Overriden configuration file:\n{}'.format(json.dumps(all_data, indent=3)))

        # Manage input paths
        kiwi_data = all_data["KIWI"]
        manage_kiwi_data(kiwi_data)

        launch_kiwi(working_directory, kiwi_data)
    except Exception as e:
        logger.error("Kiwi has failed", exc_info=True)
        import sys

        sys.exit(1)
