import numpy as np
from osgeo import gdal, osr
from tqdm import tqdm
import os
import subprocess
import logging

logger = logging.getLogger('deepforest')

def read_raster(path):
    """
    Read a raster

    :param path: Raster path
    :return: Raster as a numpy array
    """
    ds = gdal.Open(path)
    # Convert to numpy array
    b = np.array(ds.GetRasterBand(1).ReadAsArray())
    return b


def loadband_l2a(band, res=0, aoi=None, aoi_name='aoi', overwrite=False):
    """
    Load band with L2A format.

    :param band: Path to the band to be loaded
    :param res: Resampling (meters)
    :param aoi: AOI, dictionary with xmin, xmax, ymin, ymax in the same SRS than the band
    :param aoi_name: Name of the AOI (aoi by default). Can be used to set different AOI for training and testing
    :param overwrite: Overwrite bands
    :return: band as a float numpy array
    """
    band_prefix = band[:-4]

    # Convert to Geotiff if needed
    if not band.endswith('tif'):
        band_tif = band_prefix + '.tif'

        # Delete existing band if overwriting
        if os.path.exists(band_tif) and overwrite:
            os.remove(band_tif)

        # Convert the band to Geotiff
        if not os.path.exists(band_tif):
            logger.info('[%s] -- Converting to tiff ' % os.path.split(band)[-1])
            cmd = ["gdal_translate", "-of", "GTiff", band, band_tif]
            subprocess.call(cmd, stdout=open(os.devnull, 'wb'))
            band = band_tif

    # Resample if needed
    if res != 0:
        res = str(res)
        band_res = band_prefix + '_res.tif'

        # Delete existing band if overwriting
        if os.path.exists(band_res) and overwrite:
            os.remove(band_res)

        # Resample the band
        if not os.path.exists(band_res):
            logger.info('[%s] -- Resampling to %s m' % (os.path.split(band)[-1], res))
            cmd = ['gdal_translate', '-tr', res, res, band, band_res]
            subprocess.call(cmd, stdout=open(os.devnull, 'wb'))
            band = band_res
        else:
            band = band_res

    # Manage AOI
    if aoi:
        band_aoi = band_prefix + '_' + aoi_name + '.tif'

        # Delete existing band if overwriting
        if os.path.exists(band_aoi) and overwrite:
            os.remove(band_aoi)

        # Crop the band
        if not os.path.exists(band_aoi):
            try:
                xmin = str(aoi["xmin"])
                ymax = str(aoi["ymax"])
                xmax = str(aoi["xmax"])
                ymin = str(aoi["ymin"])
            except KeyError:
                raise Exception("aoi should be a dictionary with the fields xmin, xmax, ymin and ymax "
                                "specified into the same SRS than the band")

            logger.info('[%s] -- Cropping according to specified AOI' % os.path.split(band)[-1])

            # https://trac.osgeo.org/gdal/wiki/FAQRaster:
            # -projwin's ulx uly lrx lry is equivalent to xMin, yMax, xMax, yMin
            cmd = ['gdal_translate',
                   '-projwin', xmin, ymax, xmax, ymin,
                   band, band_aoi]
            subprocess.call(cmd, stdout=open(os.devnull, 'wb'))
            band = band_aoi
        else:
            band = band_aoi

    # Open image
    ds = gdal.Open(band)

    # Convert to numpy array
    b = np.array(ds.GetRasterBand(1).ReadAsArray())
    b = b.astype(np.float32)
    return b


def loadband(band, res=0, aoi=None, aoi_name='aoi', overwrite=False):
    """
    Load band (saved with a L1C format, ie. saved in integers instead of floats.
    Image returned divided by 10000.

    :param band: Path to the band to be loaded
    :param res: Resampling (meters)
    :param aoi: AOI, dictionary with xmin, xmax, ymin, ymax in the same SRS than the band
    :param aoi_name: Name of the AOI (aoi by default). Can be used to set different AOI for training and testing
    :param overwrite: Overwrite bands
    :return: band as a float numpy array
    """
    b = loadband_l2a(band, res, aoi, aoi_name, overwrite)
    return b / 10000.


def array2raster(newRasterfn, rasterfn, array, data_type=gdal.GDT_Float32):
    raster = gdal.Open(rasterfn)
    geotransform = raster.GetGeoTransform()
    originX = geotransform[0]
    originY = geotransform[3]
    pixelWidth = geotransform[1]
    pixelHeight = geotransform[5]
    cols = array.shape[1]
    rows = array.shape[0]

    driver = gdal.GetDriverByName('GTiff')
    outRaster = driver.Create(newRasterfn, cols, rows, 1, data_type)
    outRaster.SetGeoTransform((originX, pixelWidth, 0, originY, 0, pixelHeight))
    outband = outRaster.GetRasterBand(1)
    outband.WriteArray(array)
    outRasterSRS = osr.SpatialReference()
    outRasterSRS.ImportFromWkt(raster.GetProjectionRef())
    outRaster.SetProjection(outRasterSRS.ExportToWkt())
    outband.FlushCache()


def array2rasterX(newRasterfn, rasterfn, array):
    n_bands = array.shape[2]
    raster = gdal.Open(rasterfn)
    geotransform = raster.GetGeoTransform()
    originX = geotransform[0]
    originY = geotransform[3]
    pixelWidth = geotransform[1]
    pixelHeight = geotransform[5]
    cols = array.shape[1]
    rows = array.shape[0]
    driver = gdal.GetDriverByName('GTiff')
    outRaster = driver.Create(newRasterfn, cols, rows, n_bands, gdal.GDT_Float32)
    outRaster.SetGeoTransform((originX, pixelWidth, 0, originY, 0, pixelHeight))
    outRasterSRS = osr.SpatialReference()
    outRasterSRS.ImportFromWkt(raster.GetProjectionRef())
    outRaster.SetProjection(outRasterSRS.ExportToWkt())
    data = np.moveaxis(array, -1, 0)
    for i, image in enumerate(data, 1):
        outRaster.GetRasterBand(i).WriteArray(image)
    outRaster = None


def array2rasterXY(newRasterfn, array, geo_transform, projection, data_type=gdal.GDT_Float32):
    n_bands = array.shape[2]
    cols = array.shape[1]
    rows = array.shape[0]
    driver = gdal.GetDriverByName('GTiff')
    outRaster = driver.Create(newRasterfn, cols, rows, n_bands, gdal.GDT_Float32)
    outRaster.SetGeoTransform(geo_transform)
    outRaster.SetProjection(projection)
    data = np.moveaxis(array, -1, 0)
    for i, image in enumerate(data, 1):
        outRaster.GetRasterBand(i).WriteArray(image)
    outRaster = None


def array2rasterY(newRasterfn, array, geo_transform, projection, data_type=gdal.GDT_Float32):
    driver = gdal.GetDriverByName('GTiff')
    rows, cols = array.shape
    dataset = driver.Create(newRasterfn, cols, rows, 1, data_type)
    dataset.SetGeoTransform(geo_transform)
    dataset.SetProjection(projection)
    band = dataset.GetRasterBand(1)
    band.WriteArray(array)
    dataset = None  # Close the file


def read_stack(image_path):
    bands_data = []
    raster_dataset = gdal.Open(image_path, gdal.GA_ReadOnly)
    geo_transform = raster_dataset.GetGeoTransform()
    proj = raster_dataset.GetProjectionRef()
    for b in tqdm(range(1, raster_dataset.RasterCount + 1)):
        band = raster_dataset.GetRasterBand(b)
        bands_data.append(band.ReadAsArray())

    bands_data = np.dstack(bands_data)
    return bands_data, geo_transform, proj


def bincount(a):
    y = np.bincount(a)
    ii = np.nonzero(y)[0]
    return np.vstack((ii, y[ii])).T
