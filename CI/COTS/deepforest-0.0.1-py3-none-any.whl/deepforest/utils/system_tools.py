import os
import platform
import logging

logger = logging.getLogger('deepforest')


def __set_env_var_proj_lib__():
    platform_string = platform.platform()
    if 'Windows' in platform_string:
        if 'CONDA_PREFIX' in os.environ.keys():
            os.environ['PROJ_LIB'] = os.path.join(os.environ['CONDA_PREFIX'], 'Library\\share\\proj')
        else:
            os.environ['PROJ_LIB'] = os.path.join('../..', 'Library\\share\\proj')
    elif 'Linux' in platform_string:
        if 'CONDA_PREFIX' in os.environ.keys():
            os.environ['PROJ_LIB'] = os.path.join(os.environ['CONDA_PREFIX'], 'share/proj')
        else:
            os.environ['PROJ_LIB'] = os.path.join('../..', 'share/proj')


def setup_environ():
    if 'PROJ_LIB' not in os.environ:
        __set_env_var_proj_lib__()
    logger.debug("Env var '{}' is set to '{}'".format(
        'PROJ_LIB', os.environ['PROJ_LIB']
    ))
