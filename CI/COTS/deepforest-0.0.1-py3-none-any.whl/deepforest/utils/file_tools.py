import json
import os
import re
import logging

logger = logging.getLogger('deepforest')

def read_config(json_file, print_file=True):
    """
    Read a JSON configuration file

    :param json_file: path to JSON file
    :return: JSON data
    """
    with open(json_file) as f:
        data = json.load(f)
        if print_file:
            logger.debug("Configuration file {} contains:\n{}".format(json_file, json.dumps(data, indent=3)))
    return data


def get_root_directory():
    """
    Get Root directory
    :return: Root directory
    """
    return os.path.dirname((__file__))


def get_files_in_directory_by_pattern(directory, pattern_str, extension=None):
    """
    Get all files in directory corresponding to the pattern and potentially with an extension
    :param directory: Directory where to find the files
    :param pattern_str: Pattern wanted as a string
    :param extension: Extension wanted, optional. With or without point. (yaml or .yaml accepted)
    :return: List of files
    """
    # Check if the directory exists
    if not os.path.exists(directory):
        raise Exception('Non existing directory: {0}'.format(directory))

    # Get list of files
    list_files = os.listdir(directory)

    # Create pattern and sublist
    sublist = []
    pattern = re.compile(pattern_str)

    # Add point if not existing in extension
    if extension and not '.' in extension:
        extension = '.' + extension

    # Search in files
    for item in list_files:
        fileName, fileExtension = os.path.splitext(item)
        if pattern.search(item):
            if extension is None or fileExtension.lower() == extension:
                sublist.append(os.path.join(directory, item))

    return sublist