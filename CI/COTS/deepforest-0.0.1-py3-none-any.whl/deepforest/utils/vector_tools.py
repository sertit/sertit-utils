import numpy as np
import geopandas as gpd
from rasterio import features

from tqdm import tqdm

import logging
logger = logging.getLogger('deepforest')


def vectors_to_raster(file_paths, shape, crs, transform):
    """
    Rasterize, in a single image, all the vectors in the given directory.
    The data of each file will be assigned the same pixel value. This value is defined by the order
    of the file in file_paths, starting with 1: so the points/poligons/etc in the same file will be
    marked as 1, those in the second file will be 2, and so on.
    :param file_paths: Path to a directory with shapefiles
    :param shape: Shape of the image
    :param transform: Geographical transforming
    """
    labeled_pixels = np.zeros(shape)
    for i, path in enumerate(file_paths):
        logger.debug("Reading shapefile {}".format(path))
        shapefile = gpd.read_file(path).to_crs(crs)
        shapes = [feat['geometry'] for feat in shapefile.__geo_interface__['features']]
        src_image = features.rasterize(
            shapes,
            out_shape=shape,
            transform=transform
        )
        labeled_pixels += src_image * (i + 1)
    return labeled_pixels
