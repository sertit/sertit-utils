import os
import os.path
import logging
import rasterio
import rasterio.mask
import geopandas as gpd
import numpy as np
from tqdm import tqdm
from rasterio.windows import Window
from rasterio.enums import Resampling

logger = logging.getLogger('deepforest')

__OUTPUT_TO_DRIVER__ = {
    'tif': 'GTiff',
}


def __clamp__(x, a, b):
    if x < a:
        return a
    elif x > b:
        return b
    else:
        return x


class create_window_generator(object):

    def __init__(self, max_width, max_height, window_width, window_height):
        self.max_width = max_width
        self.max_height = max_height
        self.window_width = window_width
        self.window_height = window_height

        self.__init_iter__()

        self.length = len(list(self.i_iter)) * len(list(self.j_iter))
        self.__init_iter__()

        self.curr_i = next(self.i_iter)

    def __init_iter__(self):
        self.i_iter = iter(range(0, self.max_width, self.window_width))
        self.j_iter = iter(range(0, self.max_height, self.window_height))

    def __iter__(self):
        return self

    def __len__(self):
        return self.length

    # Python 3
    def __next__(self):
        return self.next()

    # Python 2
    def next(self):
        try:
            self.curr_j = next(self.j_iter)
        except StopIteration:
            self.j_iter = iter(range(0, self.max_height, self.window_height))
            self.curr_j = next(self.j_iter)
            self.curr_i = next(self.i_iter)
        actual_window_height = __clamp__(self.curr_j + self.window_height, 0, self.max_height) - self.curr_j
        actual_window_width = __clamp__(self.curr_i + self.window_width, 0, self.max_width) - self.curr_i
        return Window(self.curr_i, self.curr_j, actual_window_width, actual_window_height)


def create_output_mask_dataset(fname, src_meta, nodata=255, data_type=rasterio.ubyte):
    """
    Create a GeoTIFF file for a mask (1 band) with the given data.
    :param fname: Path to a directory with shapefiles
    :param src_meta: Meta information about the source dataset
    :param nodata: Nodata
    :param data_type: Data type
    """
    out_meta = src_meta.copy()
    out_meta["driver"] = __OUTPUT_TO_DRIVER__[fname[fname.rfind('.') + 1:]]
    out_meta["dtype"] = data_type
    out_meta["count"] = 1
    out_meta["nodata"] = nodata

    output_dataset = rasterio.open(fname, 'w+', **out_meta)

    # TODO: Implement in rasterio this
    # metadata = {
    #     'TIFFTAG_COPYRIGHT': 'CC BY 4.0',
    #     'TIFFTAG_DOCUMENTNAME': 'classification',
    #     'TIFFTAG_IMAGEDESCRIPTION': 'Supervised classification.',
    #     'TIFFTAG_MAXSAMPLEVALUE': str(len(classes)),
    #     'TIFFTAG_MINSAMPLEVALUE': '0',
    #     'TIFFTAG_SOFTWARE': 'Python, GDAL, scikit-learn'
    # }
    # dataset.SetMetadata(metadata)

    return output_dataset


def predict_on_image(model, stack_file, output_file, mask=None, runtime=None, **kwargs):
    """
    Predict on image with a given model

    :param model: Model to use to predict on image
    :param stack_file: Stack file to predict on
    :param output_file: File path where to write the prediction
    :param mask: Path to a raster binary mask file, should have the same size than the stack, and true to keep data
    :param runtime: Runtime parameters (windows, n_jobs...)
    :param kwargs: Other params used for model prediction
    """
    import warnings
    warnings.filterwarnings("ignore")

    # Output nodata and mask value
    dst_nodata = 255
    mask_val = 254

    # Manage model verbosity
    if hasattr(model, 'steps'):
        for step in model.steps:
            if hasattr(step[1], 'verbose'):
                step[1].verbose = False
    model.verbose = False

    # Manage the number of jobs provided by the Runtime
    if runtime is not None and "n_jobs" in runtime:
        if hasattr(model, 'steps'):
            for step in model.steps:
                if hasattr(step[1], 'n_jobs'):
                    step[1].n_jobs = runtime["n_jobs"]
        elif hasattr(model, 'n_jobs'):
            model.n_jobs = runtime["n_jobs"]

    # Prediction
    logger.debug("Model: {}".format(str(model)))

    # Read stack
    with rasterio.open(stack_file) as stack_ds:
        # Create output
        output_ds = create_output_mask_dataset(output_file, stack_ds.meta, nodata=dst_nodata, data_type=np.uint8)

        # In case of windowed jobs
        if runtime is not None and "Window" in runtime:
            # Create windows
            win_width = runtime["Window"][0]
            win_height = runtime["Window"][1]
            windows_iter = create_window_generator(stack_ds.width, stack_ds.height, win_width, win_height)

            # Predict on windows and write them one after another
            for window in tqdm(windows_iter):
                classification = predict_core(stack_ds.read(window=window),
                                              model,
                                              src_nodata=stack_ds.nodata,
                                              dst_nodata=dst_nodata,
                                              **kwargs)
                output_ds.write(classification, 1, window=window)

        else:
            # Predict
            classification = predict_core(stack_ds.read(),
                                          model,
                                          src_nodata=stack_ds.nodata,
                                          dst_nodata=dst_nodata,
                                          **kwargs)

            # Write classification
            output_ds.write(classification, 1)

        # Manage exclusion mask
        if mask:
            with rasterio.open(mask, "r") as mask_ds:
                # Keep where mask is True
                classif = np.where(mask_ds.read() == 1, output_ds.read(), mask_val)
                output_ds.write(classif)

        output_ds.close()

    warnings.filterwarnings("default")


def predict_core(image, model, src_nodata=None, dst_nodata=255, **kwargs):
    """ Predict on an image """

    # Flatten bands (but keep those bands appart)
    image = np.rollaxis(image, 0, 3)
    flat_pixels = image.reshape((-1, image.shape[-1]))

    # Set NaN to nodata
    if not src_nodata:
        src_nodata = 0
    flat_pixels[np.isnan(flat_pixels)] = src_nodata

    # Do not predict on nodata
    not_nodata_idx = np.nonzero(flat_pixels - src_nodata)

    # Only not nodata
    if len(not_nodata_idx[0]) == flat_pixels.shape[0]:
        flat_classification = model.predict(flat_pixels, **kwargs)
    # Some not nodata pixels exists (but not all)
    elif len(not_nodata_idx[0]) > 0:
        # Here, we set an entire pixel to nodata if at least one of the stack is set to nodata
        not_nodata_idx_1D = list(set(not_nodata_idx[0]))

        # Predict only on not nodata pixels
        flat_classification = np.full(flat_pixels.shape[0], dst_nodata, dtype=np.uint8)
        flat_classification[not_nodata_idx_1D] = model.predict(flat_pixels[not_nodata_idx_1D, :], **kwargs)
    # Only nodata
    else:
        flat_classification = np.full(flat_pixels.shape[0], dst_nodata, dtype=np.uint8)

    # TODO: choose between predict and predict_proba

    # Reshape classification to a 2D array
    classification = flat_classification.reshape(image.shape[0:2])

    return classification


# Only in loadband hereafter
def convert_to_geotiff(src_file, dst_file):
    """
     Convert a file to GEoTIFF

    :param src_file: Path to SRC image file
    :param dst_file:  Path where to write GeoTiff file
    :return:
    """
    with rasterio.open(src_file, 'r') as src:
        dst_meta = src.meta.copy()
        dst_meta['driver'] = 'GTiff'
        with rasterio.open(dst_file, 'w', **dst_meta) as dst:
            dst.write(src.read())


# Only in loadband hereafter
def resample(src_file, dst_file, x_res, y_res):
    """
    Resample a file

    :param src_file: Path to SRC image
    :param dst_file: Path whete to write resampled image
    :param x_res: X resolution in SRC CRS
    :param y_res: Y resolution in SRC CRS
    """
    logger.debug("Resampling file {} and writing resampled version to {}".format(src_file, dst_file))
    with rasterio.open(src_file, 'r') as src:
        # Compute resampling factors
        factors = src.res / np.array([x_res, y_res]).astype(np.float64)

        # Resample image
        dst_data = src.read(out_shape=(src.count,
                                       int(src.width * factors[0]),
                                       int(src.height * factors[1])),
                            resampling=Resampling.nearest)

        # Compute new transform
        dst_transform = src.transform * src.transform.scale((src.width / dst_data.shape[-2]),
                                                            (src.height / dst_data.shape[-1]))

        # Update MTD
        dst_meta = src.meta.copy()
        dst_meta.update({"height": int(src.height * factors[1]),
                         "width": int(src.width * factors[0]),
                         "transform": dst_transform})

        # Wrire destination file
        with rasterio.open(dst_file, 'w', **dst_meta) as dst:
            dst.write(dst_data)


# Only in KIWI
def loadband(band, res=0, aoi=None, aoi_name='aoi', overwrite=True):
    """
    Load band with L2A format.

    :param band: Path to the band to be loaded
    :param res: Resampling (meters)
    :param aoi: AOI, dictionary with xmin, xmax, ymin, ymax in the same SRS than the band
    :param aoi_name: Name of the AOI (aoi by default). Can be used to set different AOI for training and testing
    :param overwrite: Overwrite bands
    :return: band as a float numpy array
    """
    band_prefix = band[:-4]

    # Convert to Geotiff if needed
    if not band.endswith('tif'):
        band_tif = band_prefix + '.tif'

        # Delete existing band if overwriting
        if os.path.exists(band_tif) and overwrite:
            os.remove(band_tif)

        # Convert the band to Geotiff
        if not os.path.exists(band_tif):
            logger.debug('[%s] -- Converting to tiff ' % os.path.split(band)[-1])
            convert_to_geotiff(band, band_tif)
            band = band_tif

    # Resample if needed
    if res != 0:
        res = str(res)
        band_res = band_prefix + '_res.tif'

        # Delete existing band if overwriting
        if os.path.exists(band_res) and overwrite:
            logger.debug("Deleting file {}".format(band_res))
            os.remove(band_res)

        # Resample the band
        if not os.path.exists(band_res):
            logger.debug('[%s] -- Resampling to %s m' % (os.path.split(band)[-1], res))
            resample(band, band_res, res, res)
            band = band_res
        else:
            band = band_res

    # Open image
    ds = rasterio.open(band)
    coeff = 1 / 10000. if ds.meta['dtype'] == 'uint16' else 1.

    logger.debug("Reading file {}".format(band))
    logger.debug("Dataset's metadata:\n {}".format(ds.meta))

    # Convert to numpy array
    if aoi:
        shapefile = gpd.read_file(aoi).to_crs(ds.crs)
        shapes = [feat['geometry'] for feat in shapefile.__geo_interface__['features']]
        b, transform = rasterio.mask.mask(ds, shapes, crop=True)
        band_array = coeff * b[0, :, :].reshape(b.shape[1:]).astype(np.float32)
    else:
        b = ds.read(1)
        band_array = coeff * b.astype(np.float32)
        transform = ds.transform
    ds.close()

    return band_array, ds.crs, transform


# Only in KIWI
def array2rasterX(dst_raster_fn, array, crs, transform):
    """
    Convert array to raster

    :param dst_raster_fn: DST filename
    :param array: Array to write
    :param crs: CRS of the array
    :param transform: Transform of the array
    """
    n_bands = array.shape[2]

    dst_meta = {
        'driver': 'GTiff',
        'crs': crs,
        'transform': transform,
        'width': array.shape[0],
        'height': array.shape[1],
        'count': n_bands,
        'dtype': rasterio.float32
    }

    with rasterio.open(dst_raster_fn, 'w', **dst_meta) as dst:
        dst.write(np.rollaxis(array, 2, 0))
