import numpy as np


def safe_log(x):
    return np.log(x + 1e-7)