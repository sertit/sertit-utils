import os
import numpy as np
import rasterio
from rasterio.io import MemoryFile
from deepforest.utils.rasterio_tools import create_window_generator
from deepforest.utils.vector_tools import vectors_to_raster
from tqdm import tqdm

def read_training_data_not_windowed(stack_file, training_data):
    stack_dataset = rasterio.open(stack_file)
    classes = 0

    if training_data[-4:] == '.tif':
        train_dataset = rasterio.open(training_data, 'r')
        labeled_pixels = train_dataset.read(1)
        classes = len(np.unique(labeled_pixels.reshape(-1)))
        train_dataset.close()
    else:
        files = [f for f in os.listdir(training_data) if f.endswith('.shp')]
        classes = [f.split('.')[0] for f in files]
        shapefiles = [os.path.join(training_data, f) for f in files if f.endswith('.shp')]
        labeled_pixels = vectors_to_raster(shapefiles, stack_dataset.shape, stack_dataset.crs, stack_dataset.transform)

    data_mask = np.prod(stack_dataset.read_masks(), axis=0)
    train_mask = labeled_pixels

    is_train = np.nonzero(data_mask * train_mask)
    training_labels = labeled_pixels[is_train]

    bands_data = np.rollaxis(stack_dataset.read(), 0, 3)
    training_samples = bands_data[is_train]

    stack_dataset.close()

    return training_samples, training_labels, classes


def read_training_data_windowed(stack_file, training_data, runtime):
    stack_dataset = rasterio.open(stack_file)
    memfile = MemoryFile()
    classes = 0

    if training_data[-4:] == '.tif':
        train_dataset = rasterio.open(training_data, 'r')
        labeled_pixels = train_dataset.read(1)
        classes = len(np.unique(labeled_pixels.reshape(-1)))
    else:
        files = sorted([f for f in os.listdir(training_data) if f.endswith('.shp')])
        classes = [f.split('.')[0] for f in files]
        shapefiles = [os.path.join(training_data, f) for f in files if f.endswith('.shp')]
        labeled_pixels = vectors_to_raster(shapefiles, stack_dataset.shape, stack_dataset.crs, stack_dataset.transform)
        memfile_meta = stack_dataset.meta.copy()
        memfile_meta['count'] = 1
        memfile_meta['dtype'] = rasterio.uint8
        train_dataset = memfile.open(**memfile_meta)
        train_dataset.write(labeled_pixels.astype(np.uint8), 1)
        labeled_pixels = None

    win_width = runtime["Window"][0]
    win_height = runtime["Window"][1]

    windows_iter = create_window_generator(
        stack_dataset.meta["width"], stack_dataset.meta["height"], win_width, win_height
    )

    band_data_collection = []
    label_data_collection = []
    for window in tqdm(windows_iter, "Preparing training data"):
        band_data = np.rollaxis(stack_dataset.read(window=window), 0, 3)
        label_data = train_dataset.read(1, window=window)
        is_train = np.nonzero(label_data)
        band_data_collection.append(band_data[is_train])
        label_data_collection.append(label_data[is_train])

    train_dataset.close()
    stack_dataset.close()
    memfile.close()

    training_samples = np.concatenate(band_data_collection, axis=0)
    training_labels = np.concatenate(label_data_collection, axis=0)

    return training_samples, training_labels, classes


def read_training_data(stack_file, training_data, subsampling=1.0, runtime=None):
    if runtime is not None and "Window" in runtime:
        training_samples, training_labels, classes = read_training_data_windowed(stack_file, training_data, runtime)
    else:
        training_samples, training_labels, classes = read_training_data_not_windowed(stack_file, training_data)
    if subsampling is not None and subsampling < 1.0:
        sample_num = training_samples.shape[0]
        indices = np.random.choice(sample_num, int(sample_num * subsampling))
        return training_samples[indices], training_labels[indices], classes
    else:
        return training_samples, training_labels, classes

