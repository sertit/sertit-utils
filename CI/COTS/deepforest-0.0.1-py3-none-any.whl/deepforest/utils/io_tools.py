import os
import logging
import socket
import datetime
from deepforest.utils import file_tools
import argparse
import json


logger = logging.getLogger("deepforest")


class ContextFilter(logging.Filter):

    hostname = socket.gethostname()

    def filter(self, record):
        record.hostname = ContextFilter.hostname
        return True


def create_working_directory(module_name, output_dir=None, subfolder_name=None, create_date_folder=True):
    """
    Create working directory inside the output directory
    Possibility to add a subfolder between output directory and module directory
    The date folder will have the pattern: YYYYMMDD_HHMM
    File Tree: working directory = OUTPUT/(SUBFOLDER)/MODULE/(DATE)
    :param module_name: Module name
    :param output_dir: Output directory (relative or absolute path)
    :param subfolder_name: Set a subfolder between output directory and module directory
    :param create_date_folder: Boolean to create the final date folder
    :return:
    """
    # Variables used for monitoring and figures #
    # contains the timestamp (YYYYMMDD_HHMM) which will suffix the saved data
    date = datetime.datetime.today().replace(microsecond=0).strftime("%y%m%d_%H%M")

    # Output directory
    path_to_root = file_tools.get_root_directory()
    if not output_dir:
        output_dir = os.path.join(os.path.dirname(path_to_root), "OUTPUT")
    output_dir = os.path.abspath(output_dir)

    # Add subfolder
    if subfolder_name:
        output_dir = os.path.join(output_dir, subfolder_name)

    # Working directory
    working_dir = os.path.join(output_dir, module_name)

    # Create the date folder if needed
    if create_date_folder:
        working_dir = os.path.join(working_dir, date)

    # Create the working and the output directories if not existing
    if not os.path.exists(working_dir):
        os.makedirs(working_dir)

    # return working directory
    return working_dir


def create_console_and_file_logger(working_directory, log_file_name,
                                   log_file_verbosity=logging.INFO,
                                   log_console_verbosity=logging.INFO):
    """
    Create a file and console logger
    :param working_directory: Output directory for the logfile
    :param log_file_name: Log file name
    :param log_file_verbosity: Log file verbosity, to be given as logging.INFO/DEBUG/WARNING/ERROR
    :param log_console_verbosity: Log console verbosity, to be given as logging.INFO/DEBUG/WARNING/ERROR
    """
    # Get root logger
    logger.info("Overring logger configuration")

    logger.setLevel(logging.DEBUG)
    logger.addFilter(ContextFilter())

    formatter = logging.Formatter(
        '%(asctime)s @ %(hostname)s - [%(levelname)s] - %(filename)s . %(lineno)d: %(message)s'
    )

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(log_console_verbosity)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # Get logger file output path
    log_path = os.path.join(working_directory, log_file_name)

    # Create file handler
    fh = logging.FileHandler(log_path)
    fh.setLevel(log_file_verbosity)
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # Remove basic handler
    try:
        logging.getLogger('').removeHandler(logging.getLogger('').handlers[0])
    except:
        pass


def copy_config_in_output_dir(config_data, working_directory):
    """
    Copy the configuration file in the output directory
    Configuration file path can be specified with absolute or relative paths.

    :param config_data: Configuration data to be copied
    :param working_directory: Output directory (given by absolute or relative path)
    """
    # Test existence of the output directory
    working_directory = os.path.abspath(working_directory)
    if not os.path.exists(working_directory):
        if not os.path.exists(working_directory):
            raise Exception('Non existing output directory: {}'.format(working_directory))

    # Get filename and delete original file path
    config_name = os.path.basename(config_data["Config File Path"])
    config_data.pop("Config File Path", None)

    # Convert data into JSON
    output_config_filepath = os.path.join(working_directory, config_name)
    with open(output_config_filepath, 'w') as output_config_file:
        json.dump(config_data, output_config_file, indent=3)


def init_io(data, module_name):
    """
    Initialize inputs and outputs:
    * Create Output and working directory
    * Create file and console logger
    * Copy configuration file into output
    Returns working directory and logger name
    :param data: Dictionary containing needed data
    :param module_name: Module name
    :return: Working directory and logger name
    """

    # Get IO data
    data_io = data["IO"]
    output_dir = data_io["Output Directory"]
    subdirectory_name = data_io["Output Subdirectory"]
    create_date_folder = data_io["Create Date Folder"]

    # Get log data
    data_log = data["Log"]
    log_file_name = data_log["Log File Name"]
    log_file_verbosity = data_log["Log File Verbosity"]
    log_stream_verbosity = data_log["Log Stream Verbosity"]

    # Create working directory
    working_directory = create_working_directory(module_name, output_dir, subdirectory_name, create_date_folder)

    # Create loggers
    create_console_and_file_logger(working_directory, log_file_name, log_file_verbosity, log_stream_verbosity)

    # Copy file in the output
    copy_config_in_output_dir(data, working_directory)

    return working_directory


def parse_and_override_config_file(cmd_line_args, corresponding_keys, print_config_file=False):
    """
    Parse configuration file and overrides it with the command line arguments
    :param cmd_line_args: Command line arguments from parser
    :param corresponding_keys: Correspondence between configuration and parser keys
    :param print_config_file: Print configuration file
    :return: overridden data
    """
    if isinstance(cmd_line_args, argparse.Namespace):
        cmd_line_args = vars(cmd_line_args)
    # Check existence
    config_file_path = os.path.abspath(cmd_line_args['config'])
    if not os.path.exists(config_file_path):
        raise Exception("Non existing configuration file: {}".format(config_file_path))

    # Parse configuration file
    data = file_tools.read_config(config_file_path, print_config_file)

    # Add configuration file path
    data["Config File Path"] = config_file_path

    # -- Manage mandatory arguments
    mandatory_args = ["IO"]
    if not all(mandatory_key in data for mandatory_key in mandatory_args):
        raise Exception('Missing mandatory argument in {}'.format(mandatory_args))

    # Output directory
    data_io = data["IO"]
    if "Output Directory" not in data_io:
        raise Exception("Missing output directory")

    # Output subdirectory
    if "Output Subdirectory" not in data_io:
        data_io["Output Subdirectory"] = ""

    # Create Date Folder
    if "Create Date Folder" not in data_io:
        data_io["Create Date Folder"] = True
    else:
        data_io["Create Date Folder"] = str_to_bool(data_io["Create Date Folder"])

    # Log file name
    if not 'Log' in data:
        data['Log'] = {}

    data_log = data['Log']
    if "Log File Name" not in data_log:
        data_log["Log File Name"] = "log.txt"
    else:
        log = os.path.basename(data_log["Log File Name"])
        if len(os.path.splitext(log)) < 2:
            log = log + '.txt'
        data_log["Log File Name"] = log

    # Log file level
    if "Log File Verbosity" not in data_log:
        data_log["Log File Verbosity"] = logging.DEBUG
    else:
        data_log["Log File Verbosity"] = str_to_verbosity(data_log["Log File Verbosity"])

    # Log stream level
    if "Log Stream Verbosity" not in data_log:
        data_log["Log Stream Verbosity"] = logging.INFO
    else:
        data_log["Log Stream Verbosity"] = str_to_verbosity(data_log["Log Stream Verbosity"])

    # Override data
    for config_keys_str, overriding_key in corresponding_keys.items():
        # Check if overriding arguments have been given for this key
        if cmd_line_args[overriding_key] is not None:
            config_keys_list = str.split(config_keys_str, '/')
            nested_set(data, config_keys_list, cmd_line_args[overriding_key])
            logger.debug('Overriding parameter {} with {}'.format(config_keys_str, cmd_line_args[overriding_key]))

    return data


def nested_set(dic, keys, value):
    """
    Set value in nested directory
    :param dic: Dictionary
    :param keys: Keys as a list
    :param value: Value to be set
    """
    for key in keys[:-1]:
        dic = dic.setdefault(key, {})
    dic[keys[-1]] = value


def create_io_overriding_argparser():
    """
    Create a default argument parser with options to parse the default configuration file with the following options:
    - configuration file
    - IO:
        - output directory
        - output subdirectory
        - create date directory
    - Logger:
        - log filename
        - logger name
        - log file verbosity
        - log stream verbosity

    Create also the correspondence between JSON and command line keys.
    Nested JSON keys should be delimited by "/"

    :return: Default parser and default corresponding keys
    """

    # Create parser
    parser = argparse.ArgumentParser()

    # Add config file path key
    parser.add_argument("--config", help="Config file path (absolute or relative)", required=True)

    # Add IO overriding argument (only useful ones)
    parser.add_argument("-od", "--output_dir", help="Output Directory (absolute or relative)")
    parser.add_argument("-of", "--output_subdir", help='Output Subdirectory, i.e. TEST')
    parser.add_argument("-df", "--create_date_dir",
                        help='Create date directory: {true, yes, t, y, 1} or {false, no, f, n, 0}',
                        type=str_to_bool)

    # Add logger overriding argument (only useful ones)
    parser.add_argument("-lf", "--log_file_name", help='Log filename, i.e. log.txt')
    parser.add_argument("-fv", "--log_file_verbosity", help='Logfile verbosity: '
                                                            'DEBUG {debug, d, 10}, '
                                                            'INFO {info, i, 20}, '
                                                            'WARNING {warning, warn, w, 30}, '
                                                            'ERROR  : {error, err, e, 40}.', type=str_to_verbosity)
    parser.add_argument("-sv", "--log_stream_verbosity", help='Log stream verbosity: '
                                                              'DEBUG {debug, d, 10}, '
                                                              'INFO {info, i, 20}, '
                                                              'WARNING {warning, warn, w, 30}, '
                                                              'ERROR  : {error, err, e, 40}.', type=str_to_verbosity)

    # Create corresponding directory (to be completed !)
    corresponding_keys = {'IO/Output Directory': 'output_dir',
                          'IO/Output Subdirectory': 'output_subdir',
                          'IO/Create Date Folder': 'create_date_dir',
                          'Log/Log File Name': 'log_file_name',
                          'Log/Log File Verbosity': 'log_file_verbosity',
                          'Log/Log Stream Verbosity': 'log_stream_verbosity'}

    return parser, corresponding_keys


def str_to_verbosity(verbosity_str):
    """
    Return a logging level from a string.
    DEBUG   <=> {debug, d, 10}
    INFO    <=> {info, i, 20}
    WARNING <=> {warning, w, warn}
    ERROR   <=> {error, e, err}
    :param verbosity_str: String to be converted
    :return: Logging level (INFO, DEBUG, WARNING, ERROR)
    """

    if isinstance(verbosity_str, int):
        return verbosity_str

    debug_str = ('debug', 'd', 10)
    info_str = ('info', 'i', 20)
    warn_str = ('warning', 'w', 'warn', 30)
    err_str = ('error', 'e', 'err', 40)

    if verbosity_str.lower() in info_str:
        verbosity = logging.INFO
    elif verbosity_str.lower() in debug_str:
        verbosity = logging.DEBUG
    elif verbosity_str.lower() in warn_str:
        verbosity = logging.WARNING
    elif verbosity_str.lower() in err_str:
        verbosity = logging.ERROR
    else:
        raise argparse.ArgumentTypeError('Incorrect logging level value: {}, should be {}, {}, {} or {}'.format(
            verbosity_str, info_str, debug_str, warn_str, err_str))

    return verbosity


def str_to_bool(bool_str):
    """
    Convert a string to a bool.
    Accepted values (in any letter case):
    - True <=> yes, true, t, 1
    - True <=> no, false, f, 0
    :param bool_str: Bool as a string
    :return: Boolean value
    """

    if isinstance(bool_str, bool):
        return bool_str

    true_str = ("yes", "true", "t", "y", "1")
    false_str = ("no", "false", "f", "n", "0")

    if bool_str.lower() in true_str:
        bool_val = True
    elif bool_str.lower() in false_str:
        bool_val = False
    else:
        raise Exception("Invalid true or false value, should be {} if True or {} if False, not {}".format(
            true_str, false_str, bool_str))
    return bool_val
