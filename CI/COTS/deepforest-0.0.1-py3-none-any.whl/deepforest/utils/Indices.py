#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np

np.seterr(divide='ignore', invalid='ignore')

INDICE_TO_BAND = {}


# Vegetation indices

# In[67]:
def RGI(b):
    return np.divide(b['04'], b['03'])


INDICE_TO_BAND['RGI'] = ['04', '03']


# In[68]:


def NDVI(b):
    return np.divide((b['08'] - b['04']), (b['08'] + b['04']))


INDICE_TO_BAND['NDVI'] = ['04', '08']


# In[69]:


def TCBRI(b):
    return ((0.3037 * b['02']) + (0.2793 * b['03']) + (0.4743 * b['04']) + (0.5585 * b['08']) +
            (0.5082 * b['10']) + (0.1863 * b['12']))


INDICE_TO_BAND['TCBRI'] = ['02', '03', '04', '08', '10', '12']


# In[87]:


def TCBRE(b):
    return np.subtract(((0.7243 * b['08']) + (0.0840 * b['11'])),
                       ((0.2848 * b['02']) + (0.2435 * b['03']) + (0.5436 * b['04']) + (0.1800 * b['12'])))


INDICE_TO_BAND['TCBRE'] = ['02', '03', '04', '08', '11', '12']


# In[88]:


def TCWET(b):
    return np.subtract(((0.1509 * b['02']) + (0.1973 * b['03']) + (0.3279 * b['04']) + (0.3406 * b['08'])),
                       ((0.7112 * b['11']) + (0.4572 * b['12'])))


INDICE_TO_BAND['TCWET'] = ['02', '03', '04', '08', '11', '12']


# In[72]:


def NDRE2(b):
    return np.divide((b['08'] - b['05']), (b['08'] + b['05']))


INDICE_TO_BAND['NDRE2'] = ['05', '08']


# In[73]:


def NDRE3(b):
    return np.divide((b['08'] - b['06']), (b['08'] + b['06']))


INDICE_TO_BAND['NDRE3'] = ['06', '08']


# In[74]:


def GLI(b):
    return np.divide((2 * (b['03'] - b['04'] - b['02'])), (2 * (b['03'] + b['04'] + b['02'])))


INDICE_TO_BAND['GLI'] = ['02', '03', '04']


# In[75]:


def GNDVI(b):
    return np.divide((b['08'] - b['03']), (b['08'] + b['03']))


INDICE_TO_BAND['GNDVI'] = ['03', '08']


# In[76]:


def NDGRI(b):
    return np.divide((b['03'] - b['04']), (b['03'] + b['04']))


INDICE_TO_BAND['NDGRI'] = ['03', '04']


def NDGR(b):
    return NDGRI(b)


INDICE_TO_BAND['NDGR'] = ['03', '04']


# In[77]:


def CIG(b):
    return (np.divide(b['08'], b['03'])) - 1


INDICE_TO_BAND['CIG'] = ['03', '08']


# In[78]:


def PGR(b):
    return np.divide((b['03'] - b['02']), (b['03'] + b['02']))


INDICE_TO_BAND['PGR'] = ['03', '02']


# Water indices

# In[79]:


def NDMI(b):
    return np.divide((b['08'] - b['11']), (b['08'] + b['11']))


INDICE_TO_BAND['NDMI'] = ['08', '11']


# In[80]:


def DSWI(b):
    return np.divide((b['08'] + b['03']), (b['11'] + b['04']))


INDICE_TO_BAND['DSWI'] = ['03', '04', '08', '11']


# In[90]:


def LWCI(b):
    return np.divide((np.log(1 - (b['08'] - b['11']))), (-np.log(1 - (b['08'] - b['11']))))


INDICE_TO_BAND['LWCI'] = ['08', '11']


# In[82]:


def SRSWIR(b):
    return np.divide(b['11'], b['12'])


INDICE_TO_BAND['SRSWIR'] = ['11', '12']


# In[83]:


def RDI(b):
    return np.divide(b['11'], b['08'])


INDICE_TO_BAND['RDI'] = ['08', '11']


# In[84]:


def NDWI(b):
    return np.divide((b['03'] - b['08']), (b['03'] + b['08']))


INDICE_TO_BAND['NDWI'] = ['03', '08']


# In[91]:


def BAI(b):
    return np.divide(1, ((0.1 - b['04']) ** 2 + (0.06 - b['08']) ** 2))


INDICE_TO_BAND['BAI'] = ['04', '08']


# In[ ]:


def NBR(b):
    return np.divide((b['08'] - b['12']), (b['08'] + b['12']))


INDICE_TO_BAND['NBR'] = ['08', '12']


def MNDWI(b):
    return np.divide((b['03'] - b['11']), (b['03'] + b['11']))


INDICE_TO_BAND['MNDWI'] = ['03', '11']


def AWEInsh(b):
    return 4 * (b['03'] - b['11']) - (0.25 * b['08'] + 2.75 * b['12'])


INDICE_TO_BAND['AWEInsh'] = ['03', '08', '11', '12']


def AWEIsh(b):
    return b['02'] + 2.5 * b['03'] - 1.5 * (b['08'] + b['11']) - 0.25 * b['12']


INDICE_TO_BAND['AWEIsh'] = ['02', '03', '08', '11', '12']


def WI(b):
    return 1.7204 + 171 * b['03'] + 3 * b['04'] - 70 * b['08'] - 45 * b['11'] - 71 * b['12']


INDICE_TO_BAND['WI'] = ['03', '04', '08', '11', '12']
