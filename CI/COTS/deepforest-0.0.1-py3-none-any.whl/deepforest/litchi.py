import os
import logging

from deepforest.utils.system_tools import setup_environ

if os.path.exists('logging_config.ini'):
    print("Reading logging config file")
    logging.config.fileConfig('logging_config.ini')
# else:
#     logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('deepforest')
logger.debug('Logger was set up')

setup_environ()

import pickle
from deepforest.utils import io_tools, rasterio_tools
import json


def add_litchi_keys(litchi_parser, litchi_corresponding_keys):
    """
    Add litchi specific keys to the parser and to the correspondence dictionary.
    :param litchi_parser: litchi parser
    :param litchi_corresponding_keys: Correspondence dictionary
    :return: litchi parser and correspondence dictionary
    """
    # Pre-Trained Model
    litchi_parser.add_argument('-m', '--model', help='Pre-trained model (relative or absolute path)')
    litchi_corresponding_keys["LITCHI/Pre-Trained Model"] = "model"

    # Pre-Trained Model
    litchi_parser.add_argument('-s', '--stack', help='Stack File (relative or absolute path)')
    litchi_corresponding_keys["LITCHI/Stack File"] = "stack"

    # Keras Architecture
    litchi_parser.add_argument("-k", "--keras_architecture",
                               help="Keras Architecture for NN model (relative or absolute path)")
    litchi_corresponding_keys["LITCHI/Keras Architecture Path"] = "keras_architecture"

    # Pre-Trained Model
    litchi_parser.add_argument('-sf', '--suffix', help='Optional Suffix, i.e. _TEST')
    litchi_corresponding_keys["LITCHI/Optional Prefix"] = "suffix"

    # Pre-Trained Model
    litchi_parser.add_argument('--mask', help='Mask (relative or absolute path)')
    litchi_corresponding_keys["LITCHI/Mask"] = "mask"

    return litchi_parser, litchi_corresponding_keys


def manage_litchi_data(litchi_data_dict):
    """
    - Manage mandatory and optional arguments
    - Check existence and save absolute path in kiwi data dictionary
    :param litchi_data_dict: litchi data dictionary
    """
    # -- Manage mandatory arguments
    mandatory_args = ['Pre-Trained Model', 'Stack File']
    if not all(mandatory_key in litchi_data_dict for mandatory_key in mandatory_args):
        raise Exception('Missing mandatory argument in {}'.format(mandatory_args))

    # -- Manage paths
    # Pre trained model
    pt_model = os.path.abspath(litchi_data_dict["Pre-Trained Model"])
    if not os.path.exists(pt_model):
        raise Exception("Non existing Pre-Trained Model: {}".format(pt_model))
    litchi_data_dict["Pre-Trained Model"] = pt_model

    # Stack file
    stack_file = os.path.abspath(litchi_data_dict["Stack File"])
    if not os.path.exists(stack_file):
        raise Exception("Non existing Stack File: {}".format(stack_file))
    litchi_data_dict["Stack File"] = stack_file

    # Keras Architecture
    if "Keras Architecture" not in litchi_data_dict:
        litchi_data_dict["Keras Architecture"] = ""

    if litchi_data_dict["Keras Architecture"]:
        keras_archi = litchi_data_dict["Keras Architecture"]
        if not os.path.exists(keras_archi):
            raise Exception("Non existing Keras Architecture File: {}".format(keras_archi))
        litchi_data_dict["Keras Architecture"] = keras_archi

    # Epicea Mask
    if "Mask" not in litchi_data_dict:
        litchi_data_dict["Mask"] = ""

    if litchi_data_dict["Mask"]:
        mask = litchi_data_dict["Mask"]
        if not os.path.exists(mask):
            raise Exception("Non existing Mask File: {}".format(mask))
        litchi_data_dict["Mask"] = mask

    # Prefix
    if "Optional Suffix" not in litchi_data_dict:
        litchi_data_dict["Optional Suffix"] = ""


def launch_litchi(working_directory, litchi_data, runtime=None):
    # Just in case
    os.makedirs(working_directory, exist_ok=True)

    # Get litchi specific data
    model = litchi_data["Pre-Trained Model"]
    stack = litchi_data["Stack File"]
    arch = litchi_data.get("Keras Architecture")
    mask = litchi_data.get("Mask")
    suffix = litchi_data.get("Optional Suffix", "")
    verbose = logger.getEffectiveLevel() == logging.DEBUG

    # Get model name
    model_name = os.path.splitext(os.path.basename(model))[0]
    result_name = os.path.join(working_directory,
                               os.path.splitext(os.path.basename(stack))[0] + "_pred_" + model_name + suffix + ".tif")

    # Predict without keras architecture
    if arch is None or arch == '':

        # Load model
        with open(model, 'rb') as model_file:
            clf = pickle.load(model_file)

        logger.info('Model loaded')

        # Predict
        logger.info('Start prediction')
        rasterio_tools.predict_on_image(clf, stack, result_name, mask, runtime=runtime)
    # Predict with keras architecture
    else:
        from keras.models import model_from_json

        # Load model
        json_file = open(arch, 'r')
        loaded_model_json = json_file.read()
        json_file.close()
        loaded_model = model_from_json(loaded_model_json)

        # load weights into new model
        loaded_model.load_weights(model)
        logger.debug(loaded_model.summary())

        # Predict
        logger.info('Start prediction')
        rasterio_tools.predict_on_image(loaded_model, stack, result_name, mask,
                                        runtime=runtime, verbose=verbose)


if __name__ == "__main__":
    try:
        # Get default parser and default corresponding keys
        parser, corresponding_keys = io_tools.create_io_overriding_argparser()

        # Add kiwi specific keys
        parser, corresponding_keys = add_litchi_keys(parser, corresponding_keys)

        # Parse command line
        args = parser.parse_args()

        # Manage configuration
        all_data = io_tools.parse_and_override_config_file(args, corresponding_keys)

        # Initialize I/O
        working_directory = io_tools.init_io(all_data, module_name='LITCHI')
        logger.debug('Overriden configuration file:\n{}'.format(json.dumps(all_data, indent=3)))

        # Manage input paths
        litchi_data = all_data["LITCHI"]
        manage_litchi_data(litchi_data)

        runtime = all_data["Runtime"]

        launch_litchi(working_directory=working_directory, litchi_data=litchi_data, runtime=runtime)
    except Exception as e:
        logger.error("Litchi has failed.", exc_info=True)
        from sys import exit
        exit(1)

