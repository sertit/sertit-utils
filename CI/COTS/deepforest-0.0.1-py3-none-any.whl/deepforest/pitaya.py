import logging
import numpy as np
import rasterio
import os
import json
from deepforest.utils import io_tools

from deepforest.utils.training_data_reader import read_training_data


if os.path.exists('logging_config.ini'):
    print("Reading logging config file")
    logging.config.fileConfig('logging_config.ini')
# else:
#     logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('deepforest')
logger.debug('Logger was set up')


def report_and_exit(txt, *args, **kwargs):
    logger.error(txt, *args, **kwargs)
    exit(1)


def add_pitaya_keys(pitaya_parser, pitaya_corresponding_keys):
    """
    Add pitaya specific keys to the parser and to the correspondence dictionary.
    NOTE: It is not possible to override data files by command line. Please do it directly in the JSON.
    :param pitaya_parser: Pitaya parser
    :param pitaya_corresponding_keys: Correspondence dictionary
    :return: Pitaya parser and correspondence dictionary
    """
    # Classes
    pitaya_parser.add_argument("-c", "--classes",
                               help='List of classes, i.e. clouds notclouds',
                               nargs='*',
                               default=None)
    pitaya_corresponding_keys["PITAYA/Classes"] = "classes"

    # Output file
    pitaya_parser.add_argument("-o", "--output_file",
                               help="Output File Name, i.e. LabelledTraining (extension won't be taken into account)")
    pitaya_corresponding_keys["PITAYA/Output File Name"] = "output_file"

    return pitaya_parser, pitaya_corresponding_keys


def manage_pitaya_data(pitaya_data_dict):
    """
    - Manage mandatory arguments
    - Check existence and save absolute path in kiwi data dictionary
    :param pitaya_data_dict: pitaya data dictionary
    """
    # -- Manage mandatory arguments
    mandatory_args = ['Data Files', 'Classes', 'Output File Name']
    if not all(mandatory_key in pitaya_data_dict for mandatory_key in mandatory_args):
        raise Exception('Missing mandatory argument in {}'.format(mandatory_args))

    # Need at least one Data file pair Image, Samples
    data_files = pitaya_data_dict["Data Files"]
    if len(data_files) < 1:
        raise Exception("No input file.")

    # -- Manage Data files
    for data_pair in data_files:
        # Check args presence
        if "Image" not in data_pair or "Samples" not in data_pair:
            raise Exception('Missing mandatory argument (Image, Samples) in Data Files: {}'.format(data_pair))

        # Manage image path
        img_abs_path = os.path.abspath(data_pair["Image"])
        if not os.path.exists(img_abs_path):
            raise Exception('Non existing image {}'.format(img_abs_path))
        data_pair["Image"] = img_abs_path

        # Manage samples path
        samples_abs_path = os.path.abspath(data_pair["Samples"])
        if not os.path.exists(samples_abs_path):
            raise Exception('Non existing samples data {}'.format(samples_abs_path))
        if os.path.isdir(samples_abs_path) and not os.listdir(samples_abs_path):
            raise Exception("Empty samples directory: {}".format(samples_abs_path))
        if os.path.isfile(samples_abs_path) and not samples_abs_path.endswith('.tif'):
            raise Exception("Sample file should be a tiff file.")
        data_pair["Samples"] = samples_abs_path

    # Get output file name (discard extension)
    if "Output File Name" not in pitaya_data_dict or not pitaya_data_dict["Output File Name"]:
        pitaya_data_dict["Output File Name"] = 'LabelledTraining'
    else:
        pitaya_data_dict["Output File Name"] = \
            os.path.splitext(os.path.basename(pitaya_data_dict["Output File Name"]))[0]


def launch_pitaya(working_directory, pitaya_data, runtime=None):
    # Just in case
    os.makedirs(working_directory, exist_ok=True)

    # Pitaya data
    data = pitaya_data["Data Files"]
    list_class = pitaya_data["Classes"]
    final_npz = os.path.join(working_directory, pitaya_data["Output File Name"] + ".npz")

    # Define big array
    raster_ref = rasterio.open(data[0]['Image'])

    X = np.empty((0, raster_ref.count))
    Y = np.empty((0))

    raster_ref.close()

    # Assign values to labels
    classif_values = {}
    for c, classes in enumerate(list_class):
        classes = classes.lower()
        classif_values[classes] = c + 1
    logger.info("Here are the labels you gave and associated values :")
    for label in classif_values:
        logger.info('\t{}: \t{}'.format(label, classif_values[label]))

    # Process image-labels couples
    for couple in data:

        raster = os.path.abspath(couple['Image'])
        if not os.path.exists(raster):
            logger.warning("Not existing raster: {}, skipping this data couple.".format(raster))
            continue
        labels = os.path.abspath(couple['Samples'])
        if not os.path.exists(labels):
            logger.warning("Not existing samples: {}, skipping this data couple.".format(labels))
            continue

        # Processing raster input
        training_samples, training_labels, classes = read_training_data(raster, labels, runtime=runtime)

        X = np.concatenate((X, training_samples), axis=0)
        Y = np.concatenate((Y, training_labels), axis=0)

    # Saving final npz file
    np.savez(final_npz, X=X, Y=Y)
    logger.info("Final npz saved here: %s", final_npz)


if __name__ == "__main__":
    try:
        # Set root logger

        # Get default parser and default corresponding keys
        parser, corresponding_keys = io_tools.create_io_overriding_argparser()

        # Add kiwi specific keys
        parser, corresponding_keys = add_pitaya_keys(parser, corresponding_keys)

        # Parse command line
        args = parser.parse_args()

        # Manage configuration
        all_data = io_tools.parse_and_override_config_file(args, corresponding_keys)

        # Initialize I/O
        working_directory = io_tools.init_io(all_data, module_name='PITAYA')
        logger.debug('Overriden configuration file:\n{}'.format(json.dumps(all_data, indent=3)))

        # Manage input paths
        pitaya_data = all_data["PITAYA"]
        manage_pitaya_data(pitaya_data)

        launch_pitaya(
            working_directory=working_directory,
            pitaya_data=pitaya_data,
        )
        exit(0)
    except Exception as e:
        logger.error("Pitaya has failed", exc_info=True)
        exit(1)

