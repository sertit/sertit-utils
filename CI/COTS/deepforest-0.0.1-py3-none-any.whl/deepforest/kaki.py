import os
import logging

from deepforest.utils.system_tools import setup_environ

if os.path.exists('logging_config.ini'):
    print("Reading logging config file")
    logging.config.fileConfig('logging_config.ini')
# else:
#     logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('deepforest')
logger.debug('Logger was set up')

setup_environ()

import numpy as np
from deepforest.utils import io_tools, rasterio_tools

try:
    from osgeo import gdal
except ImportError:
    import gdal

import rasterio
from deepforest.utils.vector_tools import vectors_to_raster
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier

import os.path
import pickle
import json

from deepforest.utils.training_data_reader import read_training_data
from deepforest.utils.system_tools import setup_environ

# A list of "random" colors
COLORS = [
    "#000000", "#FFFF00", "#1CE6FF", "#FF34FF", "#FF4A46", "#008941", "#006FA6", "#A30059",
    "#FFDBE5", "#7A4900", "#0000A6", "#63FFAC", "#B79762", "#004D43", "#8FB0FF", "#997D87",
    "#5A0007", "#809693", "#FEFFE6", "#1B4400", "#4FC601", "#3B5DFF", "#4A3B53", "#FF2F80",
    "#61615A", "#BA0900", "#6B7900", "#00C2A0", "#FFAA92", "#FF90C9", "#B903AA", "#D16100",
    "#DDEFFF", "#000035", "#7B4F4B", "#A1C299", "#300018", "#0AA6D8", "#013349", "#00846F",
    "#372101", "#FFB500", "#C2FFED", "#A079BF", "#CC0744", "#C0B9B2", "#C2FF99", "#001E09",
    "#00489C", "#6F0062", "#0CBD66", "#EEC3FF", "#456D75", "#B77B68", "#7A87A1", "#788D66",
    "#885578", "#FAD09F", "#FF8A9A", "#D157A0", "#BEC459", "#456648", "#0086ED", "#886F4C",
    "#34362D", "#B4A8BD", "#00A6AA", "#452C2C", "#636375", "#A3C8C9", "#FF913F", "#938A81",
    "#575329", "#00FECF", "#B05B6F", "#8CD0FF", "#3B9700", "#04F757", "#C8A1A1", "#1E6E00",
    "#7900D7", "#A77500", "#6367A9", "#A05837", "#6B002C", "#772600", "#D790FF", "#9B9700",
    "#549E79", "#FFF69F", "#201625", "#72418F", "#BC23FF", "#99ADC0", "#3A2465", "#922329",
    "#5B4534", "#FDE8DC", "#404E55", "#0089A3", "#CB7E98", "#A4E804", "#324E72", "#6A3A4C",
    "#83AB58", "#001C1E", "#D1F7CE", "#004B28", "#C8D0F6", "#A3A489", "#806C66", "#222800",
    "#BF5650", "#E83000", "#66796D", "#DA007C", "#FF1A59", "#8ADBB4", "#1E0200", "#5B4E51",
    "#C895C5", "#320033", "#FF6832", "#66E1D3", "#CFCDAC", "#D0AC94", "#7ED379", "#012C58"
]


def report_and_exit(txt, *args, **kwargs):
    logger.error(txt, *args, **kwargs)
    exit(1)


def add_kaki_keys(kaki_parser, kaki_corresponding_keys):
    """
    Add kaki specific keys to the parser and to the correspondence dictionary.
    :param kaki_parser: Kaki parser
    :param kaki_corresponding_keys: Correspondence dictionary
    :return: Kaki parser and correspondence dictionary
    """
    # Stack file
    kaki_parser.add_argument("-s", "--stack", help="Stack File (relative or absolute path)")
    kaki_corresponding_keys["KAKI/Stack File"] = "stack"

    # Training Directory
    kaki_parser.add_argument("-t", "--training_data",
                             help="Training folder containing training data vectors "
                                  "or training tiff file (relative or absolute path)")
    kaki_corresponding_keys["KAKI/Training Data"] = "training_data"

    # Validation Directory
    kaki_parser.add_argument("-v", "--validation_data",
                             help="Validation folder containing validation data vectors "
                                  "or validation tiff file (relative or absolute path)")
    kaki_corresponding_keys["KAKI/Validation Data"] = "validation_data"

    # Output file
    kaki_parser.add_argument("-o", "--output_file",
                             help="Output File Name, i.e. MODEL_YYYYMMDD_ZONE (extension won't be taken into account)")
    kaki_corresponding_keys["KAKI/Output File Name"] = "output_file"

    # -- Supervised Classification
    # Method
    kaki_parser.add_argument("-m", "--method",
                             help="Supervised Classification or Neural Network Method",
                             choices=['random-forest', 'svm', 'mlp', 'dt', 'nn'])
    kaki_corresponding_keys["KAKI/Method"] = "method"

    # Number of trees
    kaki_parser.add_argument("-rft", "--rf_nof_trees",
                             help="Number of trees for random forest classification, i.e. 100",
                             type=int)
    kaki_corresponding_keys["KAKI/Random Forest/Number Of Trees"] = "rf_nof_trees"

    # -- Neural Network data
    # Keras Architecture
    kaki_parser.add_argument("-k", "--keras_architecture",
                             help="Keras Architecture for NN model (relative or absolute path)")
    kaki_corresponding_keys["KAKI/Neural Network Methods/Keras Architecture Path"] = "keras_architecture"

    # Number of epochs
    kaki_parser.add_argument("-nne", "--nn_epochs", help="Number of epochs for NN model, i.e. 5", type=int)
    kaki_corresponding_keys["KAKI/Neural Network Methods/Number Of Epochs"] = "nn_epochs"

    # Data Normalization
    kaki_parser.add_argument("-dn", "--data_normalization",
                             help="Data normalization: {true, yes, t, y, 1} or {false, no, f, n, 0}",
                             type=io_tools.str_to_bool)
    kaki_corresponding_keys["KAKI/Neural Network Methods/Data Normalization"] = "data_normalization"
    kaki_corresponding_keys["KAKI/Neural Network Methods/Number Of Epochs"] = "nn_epochs"

    # Data Normalization
    kaki_parser.add_argument("-p", "--predict",
                             help="Predict on stack: {true, yes, t, y, 1} or {false, no, f, n, 0}",
                             type=io_tools.str_to_bool)
    kaki_corresponding_keys["KAKI/Neural Network Methods/Predict On Stack"] = "predict"

    return kaki_parser, kaki_corresponding_keys


def manage_kaki_data(kaki_data_dict):
    """
    - Check existence and save absolute path in kaki data dictionary
    - Make sure that either a supervised classification method or a NN model is chosen
    - Set default parameters
    - Convert parameters if needed
    :param kaki_data_dict: kaki data dictionary
    """
    # -- Manage mandatory arguments
    mandatory_args = ['Stack File', 'Training Data', 'Method']
    if not all(mandatory_key in kaki_data_dict for mandatory_key in mandatory_args):
        raise Exception('Missing mandatory argument in {}'.format(mandatory_args))

    # Stack File
    stack_file_path = os.path.abspath(kaki_data_dict["Stack File"])
    if not os.path.exists(stack_file_path):
        raise Exception("Non existing Stack file: {}".format(stack_file_path))
    kaki_data_dict["Stack File"] = stack_file_path

    # Training directory
    training_data = os.path.abspath(kaki_data_dict["Training Data"])
    if not os.path.exists(training_data):
        raise Exception("Non existing training data: {}".format(training_data))
    if os.path.isdir(training_data) and not os.listdir(training_data):
        raise Exception("Empty training directory: {}".format(training_data))
    if os.path.isfile(training_data) and not training_data.endswith('.tif'):
        raise Exception("Training file should be a tiff file.")
    kaki_data_dict["Training Data"] = training_data

    # Validation directory
    if "Validation Data" in kaki_data_dict and kaki_data_dict["Validation Data"]:
        valid_data = os.path.abspath(kaki_data_dict["Validation Data"])
        if not os.path.exists(valid_data):
            raise Exception("Non existing validation data: {}".format(valid_data))
        if os.path.isdir(valid_data) and not os.listdir(valid_data):
            raise Exception("Empty validation directory: {}".format(valid_data))
        if os.path.isfile(valid_data) and not valid_data.endswith('.tif'):
            raise Exception("Validation file should be a tiff file.")
        kaki_data_dict["Validation Data"] = valid_data
    else:
        kaki_data_dict["Validation Data"] = ""

    # -- Check methods and set optional values
    method_choices = ['random-forest', 'svm', 'mlp', 'dt', 'nn', 'lr', 'knn']
    classif_method = kaki_data_dict["Method"]
    if classif_method not in method_choices:
        raise Exception("Not existing method, should be: {}".format(method_choices))

    # Random forest
    if classif_method is 'random-forest':
        if "Random Forest Method" not in kaki_data_dict:
            kaki_data_dict["Random Forest Method"] = {"Number Of Trees": 100}
        else:
            kaki_data_dict["Random Forest Method"] = int(kaki_data_dict["Random Forest Method"])

    # Random forest
    if classif_method is 'svm':
        if "SVM Method" not in kaki_data_dict:
            kaki_data_dict["SVM Method"] = {"Kernel": "rbf"}

    # Random forest
    if classif_method is 'mlp':
        if "MLP Method" not in kaki_data_dict:
            kaki_data_dict["MLP Method"] = {"Activation": "relu"}

    # Neural Networks
    elif classif_method is 'nn':
        if "Neural Network Methods" not in kaki_data_dict:
            raise Exception("Field with name 'Neural Network Methods' "
                            "containing at least a field 'Keras Architecture Path' "
                            "should be given for Neural Network methods")

        nn_data = kaki_data_dict["Neural Network Methods"]
        if "Keras Architecture Path" not in nn_data:
            raise Exception("A Keras Architecture should be given for Neural Network methods")

        keras_architecture = os.path.abspath(nn_data["Keras Architecture Path"])
        if not os.path.exists(keras_architecture):
            raise Exception("Non existing Keras Architecture: {}".format(keras_architecture))
        nn_data["Keras Architecture Path"] = keras_architecture

        if "Number Of Epochs" not in nn_data:
            nn_data["Number Of Epochs"] = 5
        else:
            nn_data["Number Of Epochs"] = int(nn_data["Number Of Epochs"])

    # Subsampling
    if "Subsampling" not in kaki_data_dict:
        kaki_data_dict["Subsampling"] = 1.0
    else:
        kaki_data_dict["Subsampling"] = float(kaki_data_dict["Subsampling"])

    # Normalize
    if "Data Normalization" not in kaki_data_dict:
        kaki_data_dict["Data Normalization"] = True
    else:
        kaki_data_dict["Data Normalization"] = io_tools.str_to_bool(kaki_data_dict["Data Normalization"])

    # Normalize
    if "Predict On Stack" not in kaki_data_dict:
        kaki_data_dict["Predict On Stack"] = False
    else:
        kaki_data_dict["Predict On Stack"] = io_tools.str_to_bool(kaki_data_dict["Predict On Stack"])

    # Get output file name (discard extension)
    if "Output File Name" not in kaki_data_dict or not kaki_data_dict["Output File Name"]:
        kaki_data_dict["Output File Name"] = "MODEL_" + os.path.splitext(os.path.basename(stack_file_path))[0]
    else:
        kaki_data_dict["Output File Name"] = os.path.splitext(kaki_data_dict["Output File Name"])[0]


def launch_kaki(working_directory, kaki_data, runtime=None, random_seed=None):
    # Just in case
    os.makedirs(working_directory, exist_ok=True)

    setup_environ()
    logger.debug("KAKI DATA '{}'".format(kaki_data))

    if random_seed is not None:
        np.random.seed(random_seed)

    # -- Get kaki data
    stack_file = kaki_data["Stack File"]
    train_data_path = kaki_data["Training Data"]
    validation_data_path = kaki_data.get("Validation Data")
    output_fname = os.path.join(working_directory, kaki_data["Output File Name"])
    output_raster = output_fname + '.tif'
    method = kaki_data["Method"]
    subsampling = kaki_data.get("Subsampling")
    normalize = kaki_data["Data Normalization"]
    predict = kaki_data["Predict On Stack"]
    verbose = logger.getEffectiveLevel() == logging.DEBUG

    with rasterio.open(stack_file) as stack_dataset:
        logger.debug("Process the training data")
        n_bands = stack_dataset.count

        training_samples, training_labels, classes = read_training_data(
            stack_file, train_data_path, subsampling=subsampling, runtime=runtime
        )
        logger.debug(classes)

        if method is "nn":
            from keras.models import model_from_json

            # Get NN data
            keras_archi = kaki_data["Neural Network Methods"]["Keras Architecture Path"]
            epochs = kaki_data["Neural Network Methods"]["Number Of Epochs"]

            # Open Keras Architecture
            fh = open(method, 'r')
            method_string = fh.read()

            # Create and compile model
            model = model_from_json(method_string)
            nn_input_shape = model.input_shape
            if not nn_input_shape[1] == n_bands:
                logger.error("Input shape of Neural Network does not match the number of bands")
                exit(-1)
            model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
            logger.debug("Traing the NN classifier described by architecture %s", str(method))

            # Fit model
            logger.info("Train the Neural Network")
            model.fit(training_samples, training_labels, epochs=epochs)

            # Write weights
            model_name = method[:-5] + '_' + os.path.split(output_fname)[1] + '.h5'
            model_name = os.path.join(os.path.split(output_fname)[0], model_name)
            model.save_weights(model_name)
            logger.debug("Model saved here: {}".format(model_name))

            # Predict
            if predict:
                logger.info("Classifying...")
                classification = rasterio_tools.predict_on_image(model, stack_file, output_raster, runtime=runtime,
                                                                 verbose=verbose)
                logger.info("Classification created: %s", output_fname)
        else:
            # Get classifier
            rf_est = kaki_data.get("Random Forest Method", {}).get("Number Of Trees", 100)
            kernel = kaki_data.get("SVM Method", {}).get("Kernel", "rbf")
            activation = kaki_data.get("MLP Method", {}).get("Activation", "relu")

            n_jobs = int(runtime["n_jobs"]) if (runtime is not None and "n_jobs" in runtime) else -1

            CLASSIFIERS = {
                # http://scikit-learn.org/dev/modules/generated/sklearn.ensemble.RandomForestClassifier.html
                'random-forest': RandomForestClassifier(
                    n_jobs=n_jobs, n_estimators=int(rf_est), random_state=random_seed, verbose=verbose
                ),
                # http://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
                'svm': SVC(class_weight='balanced', random_state=random_seed, kernel=kernel),
                'mlp': MLPClassifier(
                    hidden_layer_sizes=(n_bands, n_bands, n_bands), max_iter=100,
                    verbose=verbose, random_state=random_seed, activation=activation
                ),
                'dt': DecisionTreeClassifier(random_state=random_seed),
                'lr': LogisticRegression(
                    solver='sag',
                    penalty='l2', class_weight='balanced',
                    n_jobs=n_jobs, random_state=random_seed
                ),
                'knn': KNeighborsClassifier(
                    algorithm='ball_tree',
                    n_neighbors=5, weights='distance', n_jobs=n_jobs
                )
            }

            classifier = CLASSIFIERS[method]
            if normalize:
                ss = StandardScaler()
                classifier = Pipeline([('scaling', ss), ('classifier', classifier)])
                classifier.verbose = logger.getEffectiveLevel() == logging.DEBUG

            # Train model
            logger.info("Train the classifier")
            logger.debug(str(classifier))
            if method in ['lr', 'random-forest', 'knn']:
                classifier.fit(training_samples, training_labels.astype(np.uint8))
            else:
                classifier.fit(training_samples, training_labels)

            # Save model
            model_name = method + '_' + os.path.basename(output_fname) + '.sav'
            model_name = os.path.join(os.path.dirname(output_fname), model_name)
            with open(model_name, 'wb') as model_file:
                pickle.dump(classifier, model_file)
            logger.debug("Model saved here: {}".format(model_name))

            # Predict
            if predict:
                logger.info("Classifying...")
                rasterio_tools.predict_on_image(classifier, stack_file, output_raster, runtime=runtime)
                logger.info("Classification created: %s", output_raster)

            # proba = classifier.predict_proba(flat_pixels)
            # Print feature importance
            if method is "random-forest":
                logger.debug('Features importance:\n{}'.format(classifier.feature_importances_))

        # -- Validate the results
        if validation_data_path is not None and not validation_data_path == "":
            logger.debug("Process the verification (testing) data")
            shapefiles = None
            try:
                shapefiles = [os.path.join(validation_data_path, "%s.shp" % c) for c in classes]
            except OSError.FileNotFoundError as e:
                report_and_exit(str(e))

            verification_pixels = vectors_to_raster(
                shapefiles,
                stack_dataset.shape,
                stack_dataset.crs,
                stack_dataset.transform
            )
            for_verification = np.nonzero(verification_pixels)
            verification_labels = verification_pixels[for_verification]
            predicted_labels = classification[for_verification]

            logger.info("Confusion matrix:\n%s", str(
                metrics.confusion_matrix(verification_labels, predicted_labels)))
            target_names = ['Class %s' % s for s in classes]
            logger.info("Classification report:\n%s",
                        metrics.classification_report(verification_labels, predicted_labels,
                                                      target_names=target_names))
            logger.info("Classification accuracy: %f",
                        metrics.accuracy_score(verification_labels, predicted_labels))
        logger.info('Kaki is done')


if __name__ == "__main__":
    try:
        gdal.UseExceptions()

        # Get default parser and default corresponding keys
        parser, corresponding_keys = io_tools.create_io_overriding_argparser()

        # Add kaki specific keys
        parser, corresponding_keys = add_kaki_keys(parser, corresponding_keys)

        # Parse command line
        arguments = parser.parse_args()

        # Manage configuration
        all_data = io_tools.parse_and_override_config_file(arguments, corresponding_keys)

        # Initialize I/O
        working_directory = io_tools.init_io(all_data, module_name='KAKI')
        logger.debug('Overriden configuration file:\n{}'.format(json.dumps(all_data, indent=3)))

        # Manage data to have a clean dictionary ready to be used
        kaki_data = all_data["KAKI"]
        manage_kaki_data(kaki_data)

        # -- Get runtime data
        runtime = all_data["Runtime"]

        launch_kaki(
            working_directory=working_directory,
            kaki_data=kaki_data,
            runtime=runtime
        )
    except Exception as e:
        logger.error("Kaki has failed", exc_info=True)
        from sys import exit

        exit(1)
