"""
Classify a multi-band, satellite image.
Usage:
    classify.py <input_fname> <training_data> <output_fname> [--method=<classification_method>]
                                                               [--validation=<validation_data_path>]
                                                               [--data_normalization]
                                                               [--verbose]
    classify.py -h | --help
The <input_fname> argument must be the path to a GeoTIFF image.
The <training_data> argument must be a path to a directory with vector data files
(in shapefile format). These vectors must specify the target class of the training pixels. One file
per class. The base filename (without extension) is taken as class name.
If a <validation_data_path> is given, then the validation vector files must correspond by name with
the training data. That is, if there is a training file training_data/A.shp then the corresponding
validation_data_path/A.shp is expected.
The <output_fname> argument must be a filename where the classification will be saved (GeoTIFF format).
No geographic transformation is performed on the data. The raster and vector data geographic
parameters must match.
Options:
  -h --help  Show this screen.
  --method=<classification_method>      Classification method to use: random-forest (for random
                                        forest) or svm (for support vector machines)
                                        [default: random-forest]
  --validation=<validation_data_path>   If given, it must be a path to a directory with vector data
                                        files (in shapefile format). These vectors must specify the
                                        target class of the validation pixels. A classification
                                        accuracy report is writen to stdout.
  --data_normalization                  If given, mean and standard deviation normalize
  --quadratic_features                  If given, compute quandratic features
  --verbose                             If given, debug output is writen to stdout.
"""

import logging
import numpy as np
import os
from deepforest.utils import io_tools
try:
    from osgeo import gdal
except ImportError:
    import gdal
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
import os.path
import pickle
import json

if os.path.exists('logging_config.ini'):
    print("Reading logging config file")
    logging.config.fileConfig('logging_config.ini')
# else:
#     logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('deepforest')
logger.debug('Logger was set up')

def add_quetsch_keys(quetsch_parser, quetsch_corresponding_keys):
    """
    Add quetsch specific keys to the parser and to the correspondence dictionary.
    :param quetsch_parser: Quetsch parser
    :param quetsch_corresponding_keys: Correspondence dictionary
    :return: Quetsch parser and correspondence dictionary
    """
    # Training data
    quetsch_parser.add_argument("-t", "--training_data",
                                help="Training data (relative or absolute path)")
    quetsch_corresponding_keys["QUETSCH/Training Data"] = "training_data"

    # Validation Directory (not implemented yet)
    # quetsch_parser.add_argument("-v", "--validation_dir",
    #                          help="Validation folder containing validation data vectors (relative or absolute path)")
    # quetsch_corresponding_keys["QUETSCH/Validation Directory"] = "validation_dir"

    # Output file
    quetsch_parser.add_argument("-o", "--output_file",
                                help="Output File Name, i.e. Classification (extension won't be taken into account)")
    quetsch_corresponding_keys["QUETSCH/Output File Name"] = "output_file"

    # -- Supervised Classification
    # Method
    quetsch_parser.add_argument("-m", "--method",
                                help="Supervised Classification or Neural Network Method",
                                choices=['random-forest', 'svm', 'mlp', 'dt', 'nn'])
    quetsch_corresponding_keys["QUETSCH/Method"] = "method"

    # Number of trees
    quetsch_parser.add_argument("-rft", "--rf_nof_trees",
                                help="Number of trees for random forest classification, i.e. 100",
                                type=int)
    quetsch_corresponding_keys["QUETSCH/Random Forest/Number Of Trees"] = "rf_nof_trees"

    # -- Keras Architecture
    # Architecture
    quetsch_parser.add_argument("-k", "--keras_architecture",
                                help="Keras Architecture for NN model (relative or absolute path)")
    quetsch_corresponding_keys["QUETSCH/Neural Network Methods/Keras Architecture Path"] = "keras_architecture"

    # Data Normalization
    quetsch_parser.add_argument("-nne", "--nn_epochs", help="Number of epochs for NN model, i.e. 5", type=int)
    quetsch_corresponding_keys["QUETSCH/Neural Network Methods/Number Of Epochs"] = "nn_epochs"

    # Data Normalization
    quetsch_parser.add_argument("-dn", "--data_normalization",
                                help="Data normalization: {true, yes, t, y, 1} or {false, no, f, n, 0}",
                                type=io_tools.str_to_bool)
    quetsch_corresponding_keys["QUETSCH/Neural Network Methods/Data Normalization"] = "data_normalization"

    return quetsch_parser, quetsch_corresponding_keys


def manage_quetsch_data(quetsch_data_dict):
    """
    - Check existence and save absolute path in Quetsch data dictionary
    - Make sure that either a supervised classification method or a NN model is chosen
    - Set default parameters
    - Convert parameters if needed
    :param quetsch_data_dict: Quetsch data dictionary
    """
    # -- Manage mandatory arguments
    mandatory_args = ['Training Data', 'Method', 'Output File Name']
    if not all(mandatory_key in quetsch_data_dict for mandatory_key in mandatory_args):
        raise Exception('Missing mandatory argument in {}'.format(mandatory_args))

    # Training directory
    training_data = os.path.abspath(quetsch_data_dict["Training Data"])
    if not os.path.exists(training_data):
        raise Exception("Non existing training data file: {}".format(training_data))
    quetsch_data_dict["Training Data"] = training_data

    # Validation directory (not implemented yet)
    # if "Validation Directory" in quetsch_data_dict and quetsch_data_dict["Validation Directory"]:
    #     valid_dir = os.path.abspath(quetsch_data_dict["Validation Directory"])
    #     if not os.path.exists(valid_dir):
    #         raise Exception("Non existing validation directory: {}".format(valid_dir))
    #     if not os.listdir(valid_dir):
    #         raise Exception("Empty validation directory: {}".format(valid_dir))
    #     quetsch_data_dict["Validation Directory"] = valid_dir
    # else:
    #     quetsch_data_dict["Validation Directory"] = ""

    # -- Check methods and set optional values
    method_choices = ['random-forest', 'svm', 'mlp', 'dt', 'nn']
    classif_method = quetsch_data_dict["Method"]
    if classif_method not in method_choices:
        raise Exception("Not existing method, should be: {}".format(method_choices))

    # Random forest
    if classif_method is 'random-forest':
        if "Random Forest Method" not in quetsch_data_dict:
            quetsch_data_dict["Random Forest Method"] = {"Number Of Trees": 100}
        else:
            quetsch_data_dict["Random Forest Method"] = int(quetsch_data_dict["Random Forest Method"])

    # Neural Networks
    elif classif_method is 'nn':
        if "Neural Network Methods" not in quetsch_data_dict:
            raise Exception("Field with name 'Neural Network Methods' "
                            "containing at least a field 'Keras Architecture Path' "
                            "should be given for Neural Network methods")

        nn_data = quetsch_data_dict["Neural Network Methods"]
        if "Keras Architecture Path" not in nn_data:
            raise Exception("A Keras Architecture should be given for Neural Network methods")

        keras_architecture = os.path.abspath(nn_data["Keras Architecture Path"])
        if not os.path.exists(keras_architecture):
            raise Exception("Non existing Keras Architecture: {}".format(keras_architecture))
        nn_data["Keras Architecture Path"] = keras_architecture

        if "Number Of Epochs" not in nn_data:
            nn_data["Number Of Epochs"] = 5
        else:
            nn_data["Number Of Epochs"] = int(nn_data["Number Of Epochs"])

    # Normalize
    if "Data Normalization" not in quetsch_data_dict:
        quetsch_data_dict["Data Normalization"] = True
    else:
        quetsch_data_dict["Data Normalization"] = io_tools.str_to_bool(quetsch_data_dict["Data Normalization"])

    # Get output file name (discard extension)
    if "Output File Name" not in quetsch_data_dict or not quetsch_data_dict["Output File Name"]:
        quetsch_data_dict["Output File Name"] = "Classification"
    else:
        quetsch_data_dict["Output File Name"] = os.path.splitext(quetsch_data_dict["Output File Name"])[0]


if __name__ == "__main__":
    try:
        # Set root logging
        logger.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
        logger.info('.·´¯`·-> quetsch is being put on a pie! <-·´¯`·.')
        gdal.UseExceptions()

        # Get default parser and default corresponding keys
        parser, corresponding_keys = io_tools.create_io_overriding_argparser()

        # Add kaki specific keys
        parser, corresponding_keys = add_quetsch_keys(parser, corresponding_keys)

        # Parse command line
        arguments = parser.parse_args()

        # Manage configuration
        all_data = io_tools.parse_and_override_config_file(arguments, corresponding_keys)

        # Initialize I/O
        working_directory = io_tools.init_io(all_data, module_name='QUETSCH')
        logger.debug('Overriden configuration file:\n{}'.format(json.dumps(all_data, indent=3)))

        # Manage data to have a clean dictionary ready to be used
        quetsch_data = all_data["QUETSCH"]
        manage_quetsch_data(quetsch_data)

        # Get quetsch data
        training_data = quetsch_data["Training Data"]
        output_fname = os.path.join(working_directory, quetsch_data["Output File Name"])
        method = quetsch_data["Method"]
        normalize = quetsch_data["Data Normalization"]

        # LOG
        logger.info("Process the training data")

        open_data = np.load(training_data)
        X, y = open_data["X"], open_data["Y"]
        n_bands = np.shape(X)[1]
        n_samples = np.shape(X)[0]

        if method is "nn":
            from keras.models import model_from_json

            # Get NN data
            keras_archi = quetsch_data["Neural Network Methods"]["Keras Architecture Path"]
            epochs = quetsch_data["Neural Network Methods"]["Number Of Epochs"]

            # Open Keras Architecture
            fh = open(method, 'r')
            method_string = fh.read()

            # Create and compile model
            model = model_from_json(method_string)
            nn_input_shape = model.input_shape
            if not nn_input_shape[1] == n_bands:
                logger.error("Input shape of Neural Network does not match the number of bands")
                exit(-1)
            model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
            logger.debug("Training the NN classifier described by architecture %s", str(method))

            # Fit model
            logger.info("Train the Neural Network")
            model.fit(X, y, epochs=epochs)

            # Write weights
            model_name = os.path.splitext(os.path.basename(method))[0] + '_' + os.path.basename(output_fname) + '.h5'
            model_name = os.path.join(os.path.dirname(output_fname), model_name)
            model.save_weights(model_name)
            logger.debug("Model saved here: {}".format(model_name))

        else:
            # Get classifier
            rf_est = quetsch_data["Random Forest Method"]["Number Of Trees"]
            CLASSIFIERS = {
                # http://scikit-learn.org/dev/modules/generated/sklearn.ensemble.RandomForestClassifier.html
                'random-forest': RandomForestClassifier(n_jobs=6, n_estimators=int(rf_est), verbose=1),
                # http://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
                'svm': SVC(class_weight='balanced'),
                'mlp': MLPClassifier(hidden_layer_sizes=(n_bands, n_bands, n_bands), max_iter=10, verbose=True),
                'dt': DecisionTreeClassifier(random_state=0)
            }

            classifier = CLASSIFIERS[method]
            if normalize:
                ss = StandardScaler()
                classifier = Pipeline([('scaling', ss), ('classifier', classifier)])
                classifier.verbose = logger.getEffectiveLevel() == logging.DEBUG

            # Train model
            logger.info("Train the classifier")
            logger.debug(str(classifier))
            classifier.fit(X, y)

            # Save model
            model_name = method + '_' + os.path.basename(output_fname) + '.sav'
            model_name = os.path.join(os.path.dirname(output_fname), model_name)
            pickle.dump(classifier, open(model_name, 'wb'))
            logger.debug("Model saved here: {}".format(model_name))

            # #Print feature importance
            if method == 'random-forest':
                logger.debug("Features importance: \n{}".format(classifier.feature_importances_))

        logger.info('Quetsch is done')
        exit(0)
    except Exception as e:
        logger.error("Quetsch has failed", exc_info=True)
        exit(1)
